#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Author: lixiaobing
Date: 2021/09/24
Desc: 文本块抽象类，包括：标题、段落、表格
"""

from .text_token import TextToken
from .table_token import TableToken
from .figure_token import FigureToken
from .title_token import TitleToken
from .catlog_token import CatlogToken
from .header_token import HeaderToken
from .footer_token import FooterToken

type2token = {
    'table': TableToken,
    'figure': FigureToken,
    'title': TitleToken,
    'text': TextToken,
    'catlog': CatlogToken,
    'footer': FooterToken,
    'header': HeaderToken,
}
