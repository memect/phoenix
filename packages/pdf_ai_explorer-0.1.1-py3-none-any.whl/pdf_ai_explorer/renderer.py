"""渲染器模块

将节点转换为格式化文本输出。
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from .models.base import Cell, TableData
from .models.nodes import (
    FigureNode,
    HeadingNode,
    Node,
    NodeId,
    ParagraphNode,
    TableNode,
)

if TYPE_CHECKING:
    from .models.document import PDFDocument


def render_table_html(table: TableNode | TableData) -> str:
    """渲染表格为 HTML 格式
    
    Args:
        table: TableNode 或 TableData 对象
        
    Returns:
        HTML 格式的表格字符串，id 在 table 标签内
    """
    if isinstance(table, TableNode):
        cells = table.cells
        row_num = table.row_num
        col_num = table.col_num
        node_id = table.id
    else:
        cells = table.cells
        row_num = table.row_num
        col_num = table.col_num
        node_id = None
    
    if not cells:
        if node_id is not None:
            return f'<table id="{node_id}"></table>'
        return '<table></table>'
    
    # 构建单元格矩阵，处理 rowspan 和 colspan
    # 使用 None 标记被合并的单元格位置
    grid: list[list[Cell | None]] = [[None] * col_num for _ in range(row_num)]
    
    for cell in cells:
        row_idx = cell.row_index
        col_idx = cell.col_index
        
        # 确保索引在范围内
        if row_idx >= row_num or col_idx >= col_num:
            continue
            
        # 放置单元格
        grid[row_idx][col_idx] = cell
        
        # 标记被 rowspan/colspan 占用的位置（用特殊标记）
        for r in range(row_idx, min(row_idx + cell.row_span, row_num)):
            for c in range(col_idx, min(col_idx + cell.col_span, col_num)):
                if r != row_idx or c != col_idx:
                    # 使用 -1 标记被占用的位置（区别于 None 表示空单元格）
                    grid[r][c] = -1  # type: ignore
    
    # 生成 HTML
    if node_id is not None:
        lines = [f'<table id="{node_id}">']
    else:
        lines = ['<table>']
    
    for row_idx in range(row_num):
        lines.append("  <tr>")
        for col_idx in range(col_num):
            cell = grid[row_idx][col_idx]
            
            # 跳过被合并占用的位置
            if cell == -1:
                continue
            
            if cell is None:
                # 空单元格
                lines.append("    <td></td>")
            else:
                # 构建单元格标签
                attrs = []
                if cell.row_span > 1:
                    attrs.append(f'rowspan="{cell.row_span}"')
                if cell.col_span > 1:
                    attrs.append(f'colspan="{cell.col_span}"')
                
                attr_str = " " + " ".join(attrs) if attrs else ""
                
                # 判断是否使用 th（表头）
                # 简单规则：第一行或加粗的单元格使用 th
                tag = "th" if row_idx == 0 or cell.bold else "td"
                
                text = _escape_html(cell.text)
                lines.append(f"    <{tag}{attr_str}>{text}</{tag}>")
        
        lines.append("  </tr>")
    
    lines.append("</table>")
    return "\n".join(lines)


def _escape_html(text: str) -> str:
    """转义 HTML 特殊字符"""
    return (
        text.replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
        .replace('"', "&quot;")
    )


def render_outline(
    doc: PDFDocument,
    start_id: NodeId | None = None,
    depth: int = 2,
) -> str:
    """渲染文档大纲
    
    Args:
        doc: PDF 文档对象
        start_id: 起始节点 ID，None 表示从根开始
        depth: 最大深度限制
        
    Returns:
        格式化的大纲文本
        
    格式: "- {title} [ID:{id}] ({type}, p.{page})"
    """
    if start_id is not None:
        start_node = doc.get_node(start_id)
        if start_node is None:
            return f"[错误] 节点 {start_id} 不存在"
        nodes_to_render = [start_node]
        base_level = start_node.level
    else:
        # 从根节点的子节点开始
        if doc._root is None:
            return ""
        nodes_to_render = doc._root.get_children()
        base_level = 1
    
    lines: list[str] = []
    
    for node in nodes_to_render:
        _render_outline_node(node, lines, base_level, depth, 0)
    
    return "\n".join(lines)


def _render_outline_node(
    node: Node,
    lines: list[str],
    base_level: int,
    max_depth: int,
    current_depth: int,
) -> None:
    """递归渲染大纲节点
    
    Args:
        node: 当前节点
        lines: 输出行列表
        base_level: 基准层级（用于计算缩进）
        max_depth: 最大深度
        current_depth: 当前深度（从 0 开始）
    """
    if current_depth >= max_depth:
        return
    
    # 只渲染标题节点 (type="title")
    if node.type != "title":
        return
    
    # 计算缩进
    indent = "  " * current_depth
    
    # 获取节点信息
    title = node.get_title()
    node_id = node.id
    page = node.page_number
    
    # 格式化输出行（只显示标题，不显示 type）
    line = f"{indent}- {title} [ID:{node_id}, p.{page}]"
    lines.append(line)
    
    # 递归渲染子节点
    for child in node.get_children():
        _render_outline_node(child, lines, base_level, max_depth, current_depth + 1)


def render_inspect(
    node: Node,
    sibling_count: int = 5,
) -> str:
    """渲染节点透视信息
    
    Args:
        node: 要透视的节点
        sibling_count: 显示的前后兄弟节点数量
        
    Returns:
        格式化的透视信息，包含 Path, Siblings, Children, Meta 四部分
    """
    lines: list[str] = []
    
    # 标题
    title = node.get_title()
    lines.append(f"## Node: {title} [ID:{node.id}]")
    lines.append("")
    
    # 1. Path（祖先路径）
    lines.append("### Path")
    path_parts = ["根"]
    ancestors = node.get_ancestors()
    for ancestor in ancestors:
        path_parts.append(f"{ancestor.get_title()} [ID:{ancestor.id}, p.{ancestor.page_number}]")
    path_parts.append(f"**{title} [ID:{node.id}, p.{node.page_number}]**")
    lines.append(" > ".join(path_parts))
    lines.append("")
    
    # 2. Siblings（兄弟节点）
    lines.append(f"### Siblings (前后各{sibling_count}个)")
    siblings = node.get_siblings()
    
    # 找到当前节点在兄弟中的位置
    current_index = -1
    for i, sibling in enumerate(siblings):
        if sibling.id == node.id:
            current_index = i
            break
    
    if current_index >= 0:
        # 计算显示范围
        start_idx = max(0, current_index - sibling_count)
        end_idx = min(len(siblings), current_index + sibling_count + 1)
        
        for i in range(start_idx, end_idx):
            sibling = siblings[i]
            sibling_title = sibling.get_title()
            if sibling.id == node.id:
                # 高亮当前节点
                lines.append(f"- **>> {sibling_title} [ID:{sibling.id}, p.{sibling.page_number}] <<**")
            else:
                lines.append(f"- {sibling_title} [ID:{sibling.id}, p.{sibling.page_number}]")
    else:
        # 如果找不到当前节点（例如根节点），只显示当前节点自己
        title = node.get_title()
        lines.append(f"- **>> {title} [ID:{node.id}, p.{node.page_number}] <<**")
    
    lines.append("")
    
    # 3. Children（子节点）
    lines.append("### Children")
    children = node.get_children()
    if children:
        for child in children:
            child_title = child.get_title()
            lines.append(
                f"- {child_title} [ID:{child.id}] ({child.type}, p.{child.page_number})"
            )
    else:
        lines.append("(无子节点)")
    lines.append("")
    
    # 4. Meta（元信息）
    lines.append("### Meta")
    lines.append(f"- Type: {node.type}")
    lines.append(f"- Level: {node.level}")
    
    # 页面范围
    if node.page_number == node.end_page_number:
        lines.append(f"- Pages: {node.page_number}")
    else:
        lines.append(f"- Pages: {node.page_number}-{node.end_page_number}")
    
    # 如果是跨页表格，显示额外信息
    if isinstance(node, TableNode):
        if node.is_merged:
            lines.append(f"- 跨页表格: 是")
            if node.merged_page_ids:
                lines.append(f"- 分页 IDs: {', '.join(node.merged_page_ids)}")
        elif node.is_merged_part:
            lines.append(f"- 跨页表格分页: 是")
            if node.merged_parent_id:
                lines.append(f"- 原始表格 ID: {node.merged_parent_id}")
    
    return "\n".join(lines)



def render_search_results(
    nodes: list[Node],
    query: str,
) -> str:
    """渲染搜索结果
    
    Args:
        nodes: 匹配的节点列表
        query: 搜索查询字符串
        
    Returns:
        格式化的搜索结果文本
    """
    lines: list[str] = []
    
    # 清理查询字符串中的换行符
    clean_query = query.replace("\n", " ").replace("\r", " ").strip()
    
    # 标题
    lines.append(f'## 搜索结果: "{clean_query}" (共 {len(nodes)} 条)')
    lines.append("")
    
    if not nodes:
        lines.append("(无匹配结果)")
        return "\n".join(lines)
    
    # 渲染每个结果
    for i, node in enumerate(nodes, 1):
        node_id = node.id
        node_type = node.type
        page = node.page_number
        
        # 获取预览文本
        preview = _get_search_preview(node, query)
        
        lines.append(f'{i}. [ID:{node_id}] ({node_type}, p.{page}) "{preview}"')
    
    return "\n".join(lines)


def _get_search_preview(node: Node, query: str, max_length: int = 50) -> str:
    """获取搜索结果的预览文本
    
    尝试在匹配位置周围提取上下文。
    """
    text = node.get_searchable_text()
    if not text:
        # 如果没有可搜索文本，返回节点类型作为占位符
        return f"[{node.type}]"
    
    # 尝试找到查询字符串的位置
    query_lower = query.lower()
    text_lower = text.lower()
    
    pos = text_lower.find(query_lower)
    if pos >= 0:
        # 在匹配位置周围提取上下文
        start = max(0, pos - 10)
        end = min(len(text), pos + len(query) + max_length - 10)
        preview = text[start:end]
        
        # 添加省略号
        if start > 0:
            preview = "..." + preview
        if end < len(text):
            preview = preview + "..."
    else:
        # 没找到匹配，返回开头部分
        preview = text[:max_length]
        if len(text) > max_length:
            preview += "..."
    
    # 清理换行符
    preview = preview.replace("\n", " ").strip()
    
    # 确保预览不为空
    if not preview:
        preview = f"[{node.type}]"
    
    return preview



def render_page(
    doc: PDFDocument,
    page_num: int,
    include_structure: bool = True,
) -> str:
    """渲染页面内容
    
    Args:
        doc: PDF 文档对象
        page_num: 页码
        include_structure: 是否包含页面结构头部
        
    Returns:
        格式化的页面内容
    """
    # 验证页码
    if page_num < 1 or page_num > doc.total_pages:
        return f"[错误] 页码 {page_num} 不存在（文档共 {doc.total_pages} 页）"
    
    lines: list[str] = []
    
    # 获取页面节点
    nodes = doc.get_nodes_by_page(page_num)
    
    # 1. 页面结构头部
    if include_structure:
        lines.append(f"## [Page {page_num} Structure]")
        for node in nodes:
            level = node.level
            title = node.get_title()
            node_id = node.id
            indent = "  " * (level - 1)
            lines.append(f"- (Level {level}) {indent}{title} [ID:{node_id}]")
        lines.append("---")
        lines.append("")
    
    # 2. 页面内容
    for node in nodes:
        content = render_content(node)
        lines.append(content)
        lines.append("")
    
    return "\n".join(lines)


def render_content(node: Node) -> str:
    """渲染节点内容
    
    Args:
        node: 要渲染的节点
        
    Returns:
        格式化的节点内容，末尾带 ^id 锚点
    """
    node_id = node.id
    
    if isinstance(node, HeadingNode):
        # 标题节点
        text = node.text or node.get_title()
        return f"{text} ^{node_id}"
    
    elif isinstance(node, ParagraphNode):
        # 段落节点
        text = node.get_text()
        return f"{text} ^{node_id}"
    
    elif isinstance(node, TableNode):
        # 表格节点（id 已在 table 标签内）
        if node.is_merged:
            # 跨页表格：显示完整表格和分页信息
            html = render_table_html(node)
            if node.merged_page_ids:
                page_info = f"\n[跨页表格，分页 IDs: {', '.join(node.merged_page_ids)}]"
                return html + page_info
            return html
        elif node.is_merged_part:
            # 跨页表格的分页部分
            html = render_table_html(node)
            parent_info = ""
            if node.merged_parent_id and node._doc:
                parent_node = node._doc.get_node(node.merged_parent_id)
                if parent_node and isinstance(parent_node, TableNode):
                    parent_info = f"\n[跨页表格第 {node.page_number} 页部分，完整表格 ID: {node.merged_parent_id}，页码范围: {parent_node.page_number}-{parent_node.end_page_number}]"
                else:
                    parent_info = f"\n[跨页表格第 {node.page_number} 页部分，完整表格 ID: {node.merged_parent_id}]"
            elif node.merged_parent_id:
                parent_info = f"\n[跨页表格第 {node.page_number} 页部分，完整表格 ID: {node.merged_parent_id}]"
            return html + parent_info
        else:
            # 普通表格
            return render_table_html(node)
    
    elif isinstance(node, FigureNode):
        # 图片节点
        parts = []
        if node.filename:
            parts.append(f"[图片: {node.filename}]")
        if node.title:
            parts.append(node.title)
        content = " ".join(parts) if parts else "[图片]"
        return f"{content} ^{node_id}"
    
    else:
        # 未知类型
        text = node.get_text() or node.get_title() or f"[{node.type}]"
        return f"{text} ^{node_id}"
