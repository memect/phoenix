"""缓存管理模块

使用 diskcache 库实现文档缓存，以文件 MD5 为 key。
缓存目录: ~/.cache/pdf-ai-explorer/
"""

import hashlib
from pathlib import Path

import diskcache

CACHE_DIR = Path.home() / ".cache" / "pdf-ai-explorer"


def _get_cache() -> diskcache.Cache:
    """获取缓存实例"""
    return diskcache.Cache(str(CACHE_DIR))


def get_file_md5(file_path: str) -> str:
    """计算文件的 MD5 哈希值
    
    Args:
        file_path: 文件路径
        
    Returns:
        MD5 哈希字符串
    """
    hasher = hashlib.md5()
    with open(file_path, "rb") as f:
        for chunk in iter(lambda: f.read(8192), b""):
            hasher.update(chunk)
    return hasher.hexdigest()


def get_cached_docjson(file_path: str) -> dict | None:
    """获取缓存的 doc.json 数据
    
    Args:
        file_path: PDF 文件路径
        
    Returns:
        缓存的 doc.json 字典，如果不存在则返回 None
    """
    md5 = get_file_md5(file_path)
    cache = _get_cache()
    return cache.get(md5)


def set_cached_docjson(file_path: str, docjson: dict) -> None:
    """缓存 doc.json 数据
    
    Args:
        file_path: PDF 文件路径
        docjson: 要缓存的 doc.json 字典
    """
    md5 = get_file_md5(file_path)
    cache = _get_cache()
    cache.set(md5, docjson)
