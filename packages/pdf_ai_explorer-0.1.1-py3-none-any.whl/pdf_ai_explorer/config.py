"""配置管理模块

使用 pydantic-settings 实现配置管理，支持多级优先级：
1. 代码参数 (override)
2. 环境变量 (MEMECT_API_URL)
3. 配置文件 (~/.config/pdf-ai-explorer/config.toml)
4. 默认值
"""

from functools import lru_cache
from pathlib import Path
from typing import Tuple, Type

from pydantic import Field
from pydantic_settings import (
    BaseSettings,
    PydanticBaseSettingsSource,
    SettingsConfigDict,
    TomlConfigSettingsSource,
)

# 常量
DEFAULT_API_URL = "http://api.memect.cn:6111/api"
ENV_VAR_NAME = "MEMECT_API_URL"
CONFIG_FILE_PATH = Path.home() / ".config" / "pdf-ai-explorer" / "config.toml"


class Settings(BaseSettings):
    """应用配置"""
    
    model_config = SettingsConfigDict(
        env_prefix="MEMECT_",
        toml_file=str(CONFIG_FILE_PATH),
        extra="ignore",
    )
    
    api_url: str = Field(default=DEFAULT_API_URL, description="API 服务器 URL")
    
    @classmethod
    def settings_customise_sources(
        cls,
        settings_cls: Type[BaseSettings],
        init_settings: PydanticBaseSettingsSource,
        env_settings: PydanticBaseSettingsSource,
        dotenv_settings: PydanticBaseSettingsSource,
        file_secret_settings: PydanticBaseSettingsSource,
    ) -> Tuple[PydanticBaseSettingsSource, ...]:
        """自定义配置源优先级：init > env > toml > defaults"""
        return (
            init_settings,
            env_settings,
            TomlConfigSettingsSource(settings_cls),
        )


@lru_cache
def get_settings() -> Settings:
    """获取配置单例（带缓存）"""
    return Settings()


def get_api_url(override: str | None = None) -> str:
    """获取 API URL，按优先级返回
    
    优先级: override > 环境变量 > 配置文件 > 默认值
    
    Args:
        override: 代码中指定的 URL，最高优先级
        
    Returns:
        API URL 字符串
    """
    if override:
        return override
    return get_settings().api_url
