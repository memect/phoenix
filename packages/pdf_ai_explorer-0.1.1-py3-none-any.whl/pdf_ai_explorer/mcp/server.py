"""MCP Server 模块

提供 MCP 工具接口，使 AI 代理能够通过 MCP 协议访问 PDF 文档。
"""

from __future__ import annotations

from functools import lru_cache
from typing import Literal

from mcp.server import FastMCP

from ..api import PDFAITool
from ..exceptions import PDFParseError

# 创建 MCP Server 实例
mcp = FastMCP("PDF-AI Explorer")


@lru_cache(maxsize=8)
def get_tool(doc_path: str, api_url: str | None = None) -> PDFAITool:
    """获取或创建 PDFAITool 实例（带 LRU 缓存）
    
    Args:
        doc_path: 文档路径
        api_url: API URL（可选）
        
    Returns:
        PDFAITool 实例
        
    Raises:
        PDFParseError: 文档加载失败
    """
    return PDFAITool(doc_path, api_url)


@mcp.tool(
    name="get_outline",
    description="获取 PDF 文档大纲。返回文档的层级结构，帮助理解文档组织。"
)
def get_outline(
    doc_path: str,
    id: str | int | None = None,
    depth: int = 2,
    api_url: str | None = None,
) -> str:
    """获取文档大纲
    
    Args:
        doc_path: 文档路径（.pdf 或 .json）
        id: 起始节点 ID，None 表示从根开始
        depth: 最大深度限制，默认 2
        api_url: API URL（可选）
        
    Returns:
        格式化的大纲文本
    """
    try:
        tool = get_tool(doc_path, api_url)
        return tool.get_outline(id, depth)
    except PDFParseError as e:
        return f"[错误] 加载文档失败: {e}"
    except Exception as e:
        return f"[错误] 获取大纲失败: {e}"


@mcp.tool(
    name="inspect_node",
    description="透视节点上下文。显示节点的祖先路径、兄弟节点、子节点和元信息，帮助理解节点在文档中的位置。"
)
def inspect_node(
    doc_path: str,
    id: str | int,
    sibling_count: int = 5,
    api_url: str | None = None,
) -> str:
    """透视节点上下文
    
    Args:
        doc_path: 文档路径（.pdf 或 .json）
        id: 节点 ID
        sibling_count: 显示的前后兄弟节点数量，默认 5
        api_url: API URL（可选）
        
    Returns:
        格式化的透视信息
    """
    try:
        tool = get_tool(doc_path, api_url)
        return tool.inspect_node(id, sibling_count)
    except PDFParseError as e:
        return f"[错误] 加载文档失败: {e}"
    except Exception as e:
        return f"[错误] 透视节点失败: {e}"


@mcp.tool(
    name="search_nodes",
    description="搜索文档内容。在标题、段落和表格单元格中搜索匹配的内容。"
)
def search_nodes(
    doc_path: str,
    query: str,
    mode: Literal["regex", "fuzzy"] = "regex",
    api_url: str | None = None,
) -> str:
    """搜索文档内容
    
    Args:
        doc_path: 文档路径（.pdf 或 .json）
        query: 搜索查询字符串
        mode: 搜索模式，"regex" 或 "fuzzy"
        api_url: API URL（可选）
        
    Returns:
        格式化的搜索结果
    """
    try:
        tool = get_tool(doc_path, api_url)
        return tool.search_nodes(query, mode)
    except PDFParseError as e:
        return f"[错误] 加载文档失败: {e}"
    except Exception as e:
        return f"[错误] 搜索失败: {e}"


@mcp.tool(
    name="read_page",
    description="读取指定页面内容。显示页面的结构和详细内容，包括段落和表格。支持单页或页码范围。"
)
def read_page(
    doc_path: str,
    page: str | int,
    end_page: int | None = None,
    include_structure: bool = True,
    api_url: str | None = None,
) -> str:
    """读取指定页面内容
    
    Args:
        doc_path: 文档路径（.pdf 或 .json）
        page: 起始页码，或页码范围字符串如 "12-15"
        end_page: 结束页码（可选），如果提供则读取 page 到 end_page 的范围
        include_structure: 是否包含页面结构头部，默认 True
        api_url: API URL（可选）
        
    Returns:
        格式化的页面内容
        
    Examples:
        read_page(doc_path, 12)           # 读取第 12 页
        read_page(doc_path, 12, 15)       # 读取第 12-15 页
        read_page(doc_path, "12-15")      # 读取第 12-15 页
    """
    try:
        tool = get_tool(doc_path, api_url)
        return tool.read_page(page, end_page, include_structure)
    except PDFParseError as e:
        return f"[错误] 加载文档失败: {e}"
    except Exception as e:
        return f"[错误] 读取页面失败: {e}"


@mcp.tool(
    name="get_content",
    description="获取节点完整内容。返回指定节点的详细内容，包括文本、表格 HTML 等。"
)
def get_content(
    doc_path: str,
    id: str | int,
    api_url: str | None = None,
) -> str:
    """获取节点完整内容
    
    Args:
        doc_path: 文档路径（.pdf 或 .json）
        id: 节点 ID
        api_url: API URL（可选）
        
    Returns:
        格式化的节点内容
    """
    try:
        tool = get_tool(doc_path, api_url)
        return tool.get_content(id)
    except PDFParseError as e:
        return f"[错误] 加载文档失败: {e}"
    except Exception as e:
        return f"[错误] 获取内容失败: {e}"


def run_server(transport: Literal["stdio", "sse", "streamable-http"] = "stdio") -> None:
    """运行 MCP Server
    
    Args:
        transport: 传输协议，默认 "stdio"
    """
    mcp.run(transport=transport)


# 允许直接运行此模块
if __name__ == "__main__":
    run_server()
