"""MCP Server 模块

提供 MCP 工具接口，使 AI 代理能够通过 MCP 协议访问 PDF 文档。
"""

from .server import (
    get_content,
    get_outline,
    get_tool,
    inspect_node,
    mcp,
    read_page,
    run_server,
    search_nodes,
)

__all__ = [
    "mcp",
    "get_tool",
    "get_outline",
    "inspect_node",
    "search_nodes",
    "read_page",
    "get_content",
    "run_server",
]
