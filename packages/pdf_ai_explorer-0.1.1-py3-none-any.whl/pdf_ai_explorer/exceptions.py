"""PDF Reader 异常类定义"""

from typing import Any


class PDFReaderError(Exception):
    """基础异常类"""
    pass


class PDFParseError(PDFReaderError):
    """PDF 解析失败异常"""
    
    def __init__(self, message: str, api_url: str | None = None):
        self.message = message
        self.api_url = api_url
        super().__init__(f"{message}" + (f" (API: {api_url})" if api_url else ""))


class NodeNotFoundError(PDFReaderError):
    """节点不存在异常"""
    
    def __init__(self, node_id: int | str):
        self.node_id = node_id
        super().__init__(f"节点不存在: {node_id}")


class PageNotFoundError(PDFReaderError):
    """页码不存在异常"""
    
    def __init__(self, page_num: int, total_pages: int | None = None):
        self.page_num = page_num
        self.total_pages = total_pages
        msg = f"页码不存在: {page_num}"
        if total_pages is not None:
            msg += f" (总页数: {total_pages})"
        super().__init__(msg)


class ConfigError(PDFReaderError):
    """配置错误异常"""
    pass
