"""PDF-AI Explorer - AI-oriented PDF document reading tool

PDF-AI Explorer 是一个面向 AI 的 PDF 文档阅读工具，将 PDF 视为带索引的拓扑图，
提供 CLI、Python SDK 和 MCP 三种接口，帮助 AI 高效导航和理解长文档。

主要类:
    PDFAITool: 面向 AI 的文本接口 SDK，返回格式化文本
    PDFReader: 结构化 SDK，返回对象，抛出异常

异常类:
    PDFReaderError: 基础异常类
    PDFParseError: PDF 解析失败
    NodeNotFoundError: 节点不存在
    PageNotFoundError: 页码不存在
    ConfigError: 配置错误

使用示例:
    >>> from pdf_ai_explorer import PDFAITool
    >>> tool = PDFAITool("document.json")
    >>> print(tool.get_outline())
    
    >>> from pdf_ai_explorer import PDFReader
    >>> reader = PDFReader("document.json")
    >>> node = reader.get_node(1)
"""

__version__ = "0.1.0"

from pdf_ai_explorer.api import PDFAITool, PDFReader
from pdf_ai_explorer.exceptions import (
    ConfigError,
    NodeNotFoundError,
    PageNotFoundError,
    PDFParseError,
    PDFReaderError,
)
from pdf_ai_explorer.search import search_nodes
from pdf_ai_explorer.skill import generate_skill

__all__ = [
    # 版本
    "__version__",
    # 主要类
    "PDFAITool",
    "PDFReader",
    # 异常类
    "PDFReaderError",
    "PDFParseError",
    "NodeNotFoundError",
    "PageNotFoundError",
    "ConfigError",
    # 工具函数
    "search_nodes",
    "generate_skill",
]

