"""文档加载器模块

提供 load_document 函数，自动识别 PDF 或 JSON 文件并加载为 PDFDocument。
"""

import json
from pathlib import Path
from typing import Any

from .cache import get_cached_docjson, set_cached_docjson
from .config import get_api_url
from .exceptions import PDFParseError
from .models import PDFDocument
from .utils.pdf_parser import parse_pdf_to_docjson


def load_document(doc_path: str, api_url: str | None = None) -> PDFDocument:
    """加载文档，自动识别 PDF 或 JSON
    
    Args:
        doc_path: 文档路径（.pdf 或 .json）
        api_url: API 服务器 URL（仅 PDF 文件需要）
        
    Returns:
        PDFDocument 对象
        
    Raises:
        FileNotFoundError: 文件不存在
        ValueError: 不支持的文件格式
        PDFParseError: PDF 解析失败
    """
    path = Path(doc_path)
    
    # 检查文件是否存在
    if not path.exists():
        raise FileNotFoundError(f"文件不存在: {doc_path}")
    
    # 根据扩展名处理
    suffix = path.suffix.lower()
    
    if suffix == ".json":
        return _load_from_json(doc_path)
    elif suffix == ".pdf":
        return _load_from_pdf(doc_path, api_url)
    else:
        raise ValueError(f"不支持的文件格式: {suffix}")


def _load_from_json(json_path: str) -> PDFDocument:
    """从 JSON 文件加载文档
    
    Args:
        json_path: JSON 文件路径
        
    Returns:
        PDFDocument 对象
    """
    with open(json_path, "r", encoding="utf-8") as f:
        data = json.load(f)
    
    return PDFDocument.from_dict(data)


def _load_from_pdf(pdf_path: str, api_url: str | None = None) -> PDFDocument:
    """从 PDF 文件加载文档
    
    优先使用缓存，未命中则调用 API 解析。
    
    Args:
        pdf_path: PDF 文件路径
        api_url: API 服务器 URL
        
    Returns:
        PDFDocument 对象
        
    Raises:
        PDFParseError: PDF 解析失败
    """
    # 检查缓存
    cached_data = get_cached_docjson(pdf_path)
    if cached_data is not None:
        return PDFDocument.from_dict(cached_data)
    
    # 读取 PDF 文件
    with open(pdf_path, "rb") as f:
        pdf_data = f.read()
    
    # 调用 API 解析
    url = get_api_url(api_url)
    docjson = parse_pdf_to_docjson(pdf_data, api_url=url)
    
    # 缓存结果
    set_cached_docjson(pdf_path, docjson)
    
    return PDFDocument.from_dict(docjson)


def load_docjson(doc_path: str, api_url: str | None = None) -> dict[str, Any]:
    """加载文档并返回原始 doc.json 数据
    
    Args:
        doc_path: 文档路径（.pdf 或 .json）
        api_url: API 服务器 URL（仅 PDF 文件需要）
        
    Returns:
        doc.json 字典数据
        
    Raises:
        FileNotFoundError: 文件不存在
        ValueError: 不支持的文件格式
        PDFParseError: PDF 解析失败
    """
    path = Path(doc_path)
    
    if not path.exists():
        raise FileNotFoundError(f"文件不存在: {doc_path}")
    
    suffix = path.suffix.lower()
    
    if suffix == ".json":
        with open(doc_path, "r", encoding="utf-8") as f:
            return json.load(f)
    elif suffix == ".pdf":
        # 检查缓存
        cached_data = get_cached_docjson(doc_path)
        if cached_data is not None:
            return cached_data
        
        # 读取并解析
        with open(doc_path, "rb") as f:
            pdf_data = f.read()
        
        url = get_api_url(api_url)
        docjson = parse_pdf_to_docjson(pdf_data, api_url=url)
        
        # 缓存结果
        set_cached_docjson(doc_path, docjson)
        
        return docjson
    else:
        raise ValueError(f"不支持的文件格式: {suffix}")
