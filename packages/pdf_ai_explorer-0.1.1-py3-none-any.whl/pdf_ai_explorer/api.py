"""Python SDK 模块

提供两种 API 接口：
- PDFAITool: 面向 AI 的文本接口，返回格式化文本
- PDFReader: 结构化接口，返回对象，抛出异常
"""

from __future__ import annotations

from typing import Iterator

from .exceptions import NodeNotFoundError, PageNotFoundError, PDFParseError
from .models.document import PDFDocument
from .models.nodes import Node, NodeId
from .parser import load_document
from .renderer import (
    render_content,
    render_inspect,
    render_outline,
    render_page,
    render_search_results,
)
from .search import search_nodes


class PDFAITool:
    """面向 AI 的文本接口 SDK
    
    所有方法返回格式化文本，错误时返回 "[错误]..." 格式。
    """
    
    def __init__(self, doc_path: str, api_url: str | None = None) -> None:
        """初始化 PDFAITool
        
        Args:
            doc_path: 文档路径（.pdf 或 .json）
            api_url: API 服务器 URL（仅 PDF 文件需要）
            
        Raises:
            PDFParseError: 文档加载失败
        """
        try:
            self._doc = load_document(doc_path, api_url)
        except FileNotFoundError as e:
            raise PDFParseError(f"文件不存在: {doc_path}") from e
        except ValueError as e:
            raise PDFParseError(str(e)) from e

    def get_outline(
        self,
        id: NodeId | None = None,
        depth: int = 2,
    ) -> str:
        """获取文档大纲
        
        Args:
            id: 起始节点 ID，None 表示从根开始
            depth: 最大深度限制，默认 2
            
        Returns:
            格式化的大纲文本，错误时返回 "[错误]..." 格式
        """
        try:
            # 验证节点存在性
            if id is not None:
                node = self._doc.get_node(id)
                if node is None:
                    return f"[错误] 节点 {id} 不存在"
            
            return render_outline(self._doc, id, depth)
        except Exception as e:
            return f"[错误] 获取大纲失败: {e}"
    
    def inspect_node(
        self,
        id: NodeId,
        sibling_count: int = 5,
    ) -> str:
        """透视节点上下文
        
        Args:
            id: 节点 ID
            sibling_count: 显示的前后兄弟节点数量，默认 5
            
        Returns:
            格式化的透视信息，错误时返回 "[错误]..." 格式
        """
        try:
            node = self._doc.get_node(id)
            if node is None:
                return f"[错误] 节点 {id} 不存在"
            
            return render_inspect(node, sibling_count)
        except Exception as e:
            return f"[错误] 透视节点失败: {e}"
    
    def search_nodes(
        self,
        query: str,
        mode: str = "regex",
    ) -> str:
        """搜索文档内容
        
        Args:
            query: 搜索查询字符串
            mode: 搜索模式，"regex" 或 "fuzzy"
            
        Returns:
            格式化的搜索结果，错误时返回 "[错误]..." 格式
        """
        try:
            nodes = search_nodes(self._doc, query, mode)
            return render_search_results(nodes, query)
        except Exception as e:
            return f"[错误] 搜索失败: {e}"
    
    def read_page(
        self,
        page_num: int | str,
        end_page: int | None = None,
        include_structure: bool = True,
    ) -> str:
        """读取指定页面内容
        
        Args:
            page_num: 起始页码，或页码范围字符串如 "12-15"
            end_page: 结束页码（可选），如果提供则读取 page_num 到 end_page 的范围
            include_structure: 是否包含页面结构头部，默认 True
            
        Returns:
            格式化的页面内容，错误时返回 "[错误]..." 格式
            
        Examples:
            read_page(12)           # 读取第 12 页
            read_page(12, 15)       # 读取第 12-15 页
            read_page("12-15")      # 读取第 12-15 页
        """
        try:
            # 解析页码范围
            start_page, final_end_page = self._parse_page_range(page_num, end_page)
            
            # 验证页码
            if start_page < 1 or start_page > self._doc.total_pages:
                return f"[错误] 起始页码 {start_page} 不存在（文档共 {self._doc.total_pages} 页）"
            if final_end_page < 1 or final_end_page > self._doc.total_pages:
                return f"[错误] 结束页码 {final_end_page} 不存在（文档共 {self._doc.total_pages} 页）"
            if start_page > final_end_page:
                return f"[错误] 起始页码 {start_page} 大于结束页码 {final_end_page}"
            
            # 渲染页面
            results = []
            for p in range(start_page, final_end_page + 1):
                results.append(render_page(self._doc, p, include_structure))
            
            return "\n\n".join(results)
        except ValueError as e:
            return f"[错误] 页码格式错误: {e}"
        except Exception as e:
            return f"[错误] 读取页面失败: {e}"
    
    def _parse_page_range(
        self,
        page_num: int | str,
        end_page: int | None,
    ) -> tuple[int, int]:
        """解析页码范围
        
        Returns:
            (start_page, end_page) 元组
        """
        if isinstance(page_num, str):
            # 解析字符串格式 "12-15" 或 "12"
            if "-" in page_num:
                parts = page_num.split("-")
                if len(parts) != 2:
                    raise ValueError(f"无效的页码范围格式: {page_num}")
                start = int(parts[0].strip())
                end = int(parts[1].strip())
                return start, end
            else:
                start = int(page_num.strip())
                return start, end_page if end_page is not None else start
        else:
            # 整数格式
            start = page_num
            return start, end_page if end_page is not None else start
    
    def get_content(self, id: NodeId) -> str:
        """获取节点完整内容
        
        Args:
            id: 节点 ID
            
        Returns:
            格式化的节点内容，错误时返回 "[错误]..." 格式
        """
        try:
            node = self._doc.get_node(id)
            if node is None:
                return f"[错误] 节点 {id} 不存在"
            
            return render_content(node)
        except Exception as e:
            return f"[错误] 获取内容失败: {e}"



class PDFReader:
    """结构化 SDK
    
    返回对象，错误时抛出异常。
    """
    
    def __init__(self, doc_path: str, api_url: str | None = None) -> None:
        """初始化 PDFReader
        
        Args:
            doc_path: 文档路径（.pdf 或 .json）
            api_url: API 服务器 URL（仅 PDF 文件需要）
            
        Raises:
            PDFParseError: 文档加载失败
            FileNotFoundError: 文件不存在
            ValueError: 不支持的文件格式
        """
        self._doc = load_document(doc_path, api_url)
    
    @property
    def total_pages(self) -> int:
        """文档总页数"""
        return self._doc.total_pages
    
    def get_node(self, id: NodeId) -> Node:
        """根据 ID 获取节点
        
        Args:
            id: 节点 ID
            
        Returns:
            Node 对象
            
        Raises:
            NodeNotFoundError: 节点不存在
        """
        node = self._doc.get_node(id)
        if node is None:
            raise NodeNotFoundError(id)
        return node
    
    def get_nodes_by_page(self, page_num: int) -> list[Node]:
        """获取指定页面的所有节点
        
        Args:
            page_num: 页码
            
        Returns:
            节点列表
            
        Raises:
            PageNotFoundError: 页码不存在
        """
        if page_num < 1 or page_num > self._doc.total_pages:
            raise PageNotFoundError(page_num, self._doc.total_pages)
        
        return self._doc.get_nodes_by_page(page_num)
    
    def search(
        self,
        query: str,
        mode: str = "regex",
    ) -> list[Node]:
        """搜索文档内容
        
        Args:
            query: 搜索查询字符串
            mode: 搜索模式，"regex" 或 "fuzzy"
            
        Returns:
            匹配的节点列表
        """
        return search_nodes(self._doc, query, mode)
    
    def iter_nodes(self, type_filter: str | None = None) -> Iterator[Node]:
        """遍历所有节点
        
        Args:
            type_filter: 可选的类型过滤器，如 "title", "section", "table", "figure"
            
        Yields:
            Node 对象
        """
        yield from self._doc.iter_nodes(type_filter)
