"""Skill 生成模块

生成 Claude Code skill.md 文件，供 AI agent 快速了解 CLI 用法。
"""

from __future__ import annotations

from pathlib import Path


def generate_skill() -> str:
    """生成 Claude Code skill 内容

    Returns:
        skill markdown 文本
    """
    template_path = Path(__file__).parent / "templates" / "skill.md"
    return template_path.read_text(encoding="utf-8")
