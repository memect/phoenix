"""搜索模块

实现文档内容搜索功能，支持 regex 和 fuzzy 模式。
"""

from __future__ import annotations

import re
from typing import TYPE_CHECKING, Iterator

from .models.nodes import Node

if TYPE_CHECKING:
    from .models.document import PDFDocument


def search_nodes(
    doc: PDFDocument,
    query: str,
    mode: str = "regex",
) -> list[Node]:
    """搜索文档内容
    
    Args:
        doc: PDF 文档对象
        query: 搜索查询字符串
        mode: 搜索模式，"regex" 或 "fuzzy"
        
    Returns:
        匹配的节点列表
        
    搜索范围：标题、段落、表格单元格
    """
    if not query:
        return []
    
    results: list[Node] = []
    
    for node in doc.iter_nodes():
        # 获取可搜索文本
        searchable_text = node.get_searchable_text()
        if not searchable_text:
            continue
        
        # 根据模式进行匹配
        if mode == "regex":
            if _match_regex(searchable_text, query):
                results.append(node)
        elif mode == "fuzzy":
            if _match_fuzzy(searchable_text, query):
                results.append(node)
        else:
            # 默认使用 regex 模式
            if _match_regex(searchable_text, query):
                results.append(node)
    
    return results


def _match_regex(text: str, pattern: str) -> bool:
    """使用正则表达式匹配
    
    Args:
        text: 要搜索的文本
        pattern: 正则表达式模式
        
    Returns:
        是否匹配
    """
    try:
        # 使用 IGNORECASE 标志进行不区分大小写的搜索
        return bool(re.search(pattern, text, re.IGNORECASE))
    except re.error:
        # 如果正则表达式无效，回退到普通字符串搜索
        return pattern.lower() in text.lower()


def _match_fuzzy(text: str, query: str) -> bool:
    """使用模糊匹配
    
    简单的模糊匹配实现：
    - 将查询拆分为单词
    - 所有单词都必须出现在文本中（不区分大小写）
    - 单词可以不连续出现
    
    Args:
        text: 要搜索的文本
        query: 查询字符串
        
    Returns:
        是否匹配
    """
    text_lower = text.lower()
    query_lower = query.lower()
    
    # 首先尝试直接匹配
    if query_lower in text_lower:
        return True
    
    # 拆分查询为单词
    words = query_lower.split()
    if not words:
        return False
    
    # 所有单词都必须出现
    return all(word in text_lower for word in words)
