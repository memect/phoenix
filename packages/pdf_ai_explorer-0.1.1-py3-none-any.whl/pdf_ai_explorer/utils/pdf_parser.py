"""PDF 解析工具模块

提供 PDF 到 doc.json 的转换功能。
"""

from typing import Any

from ..config import get_api_url
from ..exceptions import PDFParseError
from .apiserver import ApiServer


# 默认 API 参数
DEFAULT_API_PARAMS = {
    "ocr": "auto",
    "ocr-text": "baidu",
    "mode": "3",
    "textlines": "true",
    "format": "4",
    "merge-table": "true",
}


def parse_pdf_to_docjson(
    pdf_data: bytes,
    api_url: str | None = None,
    params: dict[str, str] | None = None,
) -> dict[str, Any]:
    """将 PDF 数据解析为 doc.json 格式
    
    Args:
        pdf_data: PDF 文件的二进制数据
        api_url: API 服务器 URL，为 None 时使用配置优先级
        params: API 参数，为 None 时使用默认参数
        
    Returns:
        解析后的 doc.json 字典
        
    Raises:
        PDFParseError: PDF 解析失败
    """
    url = get_api_url(api_url)
    api_params = params if params is not None else DEFAULT_API_PARAMS.copy()
    
    api = ApiServer(base_url=url)
    
    try:
        result = api.invoke(
            name="pdf2doc",
            data=pdf_data,
            params=api_params,
            output_format="json",
            async_=False,
        )
        
        if result is None:
            raise PDFParseError("API 返回空结果", api_url=url)
            
        return result
        
    except PDFParseError:
        raise
    except Exception as e:
        raise PDFParseError(str(e), api_url=url) from e


def parse_pdf_file_to_docjson(
    file_path: str,
    api_url: str | None = None,
    params: dict[str, str] | None = None,
) -> dict[str, Any]:
    """将 PDF 文件解析为 doc.json 格式
    
    Args:
        file_path: PDF 文件路径
        api_url: API 服务器 URL
        params: API 参数
        
    Returns:
        解析后的 doc.json 字典
        
    Raises:
        FileNotFoundError: 文件不存在
        PDFParseError: PDF 解析失败
    """
    with open(file_path, "rb") as f:
        pdf_data = f.read()
    
    return parse_pdf_to_docjson(pdf_data, api_url, params)
