---
name: pdf-ai-explorer
description: Use pdf-ai-explorer CLI to navigate and read PDF documents efficiently. Trigger when user wants to read, analyze, search, or navigate PDF documents.
---

# PDF-AI Explorer CLI Guide

PDF-AI Explorer treats PDF as an indexed topological graph. You navigate by node IDs and page numbers.

## Prerequisites

- A `.json` document file (pre-parsed from PDF)
- `pdf-ai-explorer` installed (`uvx` or `uv pip install pdf-ai-explorer`)

## Commands

### 1. outline — Get document outline

```bash
pdf-ai-explorer outline <doc.json> [--id ID] [--depth N]
```

- `--depth` (default: 2): max heading depth
- `--id`: start from a specific node

**Output example:**
```
- Introduction [ID:1, p.1]
  - Background [ID:3, p.1]
  - Objectives [ID:5, p.2]
- Financial Report [ID:10, p.5]
  - Revenue Analysis [ID:12, p.6]
  - Cost Structure [ID:20, p.10]
```

### 2. inspect — View node context

```bash
pdf-ai-explorer inspect <doc.json> <ID> [--siblings N]
```

- `--siblings` (default: 5): number of sibling nodes to show before/after

**Output example:**
```
## Node: Revenue Analysis [ID:12]

### Path
根 > Financial Report [ID:10, p.5] > **Revenue Analysis [ID:12, p.6]**

### Siblings (前后各5个)
- Overview [ID:11, p.5]
- **>> Revenue Analysis [ID:12, p.6] <<**
- Cost Structure [ID:20, p.10]

### Children
- Q1 Revenue [ID:13] (section, p.6)
- Q2 Revenue [ID:14] (table, p.7)

### Meta
- Type: title
- Level: 2
- Pages: 6-9
```

### 3. search — Search document content

```bash
pdf-ai-explorer search <doc.json> <query> [--mode regex|fuzzy]
```

- `--mode` (default: regex): `regex` for exact/pattern match, `fuzzy` for approximate match

**Output example:**
```
## 搜索结果: "营业收入" (共 3 条)

1. [ID:52] (table, p.8) "...营业收入 20,594,892..."
2. [ID:105] (section, p.15) "...营业收入同比增长..."
3. [ID:200] (table, p.30) "...营业收入合计..."
```

### 4. read — Read page content

```bash
pdf-ai-explorer read <doc.json> <page|page-range> [--no-structure]
```

- `page`: single page `12` or range `12-15`
- `--no-structure`: hide the page structure header

**Output example:**
```
## [Page 8 Structure]
- (Level 1)   Financial Report [ID:10]
- (Level 2)     Revenue Analysis [ID:12]
- (Level 3)       Q2 Revenue [ID:14]
---

Some paragraph text about revenue. ^105

<table id="52">
  <tr><th>项目</th><th>金额</th></tr>
  <tr><td>营业收入</td><td>20,594,892</td></tr>
</table>
```

### 5. content — Get full node content

```bash
pdf-ai-explorer content <doc.json> <ID>
```

- `ID`: integer node ID or virtual ID like `52:p9` for cross-page table parts

**Output example (normal node):**
```
Some paragraph text content. ^105
```

**Output example (cross-page table):**
```
<table id="52">
  <tr><th>项目</th><th>本期</th><th>上期</th></tr>
  <tr><td>营业收入</td><td>20,594,892</td><td>18,302,100</td></tr>
</table>
[跨页表格，分页 IDs: 52:p8, 52:p9, 52:p10]
```

## Recommended Navigation Strategy

1. **Start with outline** — `outline doc.json --depth 2` to understand document structure
2. **Drill down** — `outline doc.json --id 10 --depth 3` to expand a specific section
3. **Inspect context** — `inspect doc.json 12` to see a node's path, siblings, and children
4. **Read content** — `content doc.json 12` for a specific node, or `read doc.json 8` for a full page
5. **Search** — `search doc.json "keyword"` to locate specific content across the document

## Key Concepts

- **Node ID**: Every content block (heading, paragraph, table, figure) has a unique integer ID
- **Virtual ID**: Cross-page tables have page-specific parts like `52:p9` (table 52, page 9 portion)
- **Anchor `^id`**: Text content ends with `^id` for back-reference (e.g., `Some text ^105`)
- **Tables**: Rendered as HTML with `<table id="...">` for structured parsing
- **Error prefix**: All errors start with `[错误]`
