"""PDF-AI Explorer CLI 命令行接口

使用 Typer 实现，关闭 Rich 装饰以保持输出简洁。
"""

import sys
from typing import Optional

import typer

from .api import PDFAITool
from .exceptions import PDFParseError
from .skill import generate_skill

# 创建 Typer 应用，关闭 Rich 装饰
app = typer.Typer(
    add_completion=False,
    rich_markup_mode=None,
    pretty_exceptions_enable=False,
)


def _parse_node_id(id_str: str) -> int | str:
    """解析节点 ID 字符串
    
    Args:
        id_str: 节点 ID 字符串，可以是整数或虚拟 ID（如 "52:p9"）
        
    Returns:
        整数 ID 或字符串虚拟 ID
    """
    try:
        return int(id_str)
    except ValueError:
        return id_str


def _create_tool(doc_path: str) -> PDFAITool:
    """创建 PDFAITool 实例
    
    Args:
        doc_path: 文档路径
        
    Returns:
        PDFAITool 实例
        
    Raises:
        typer.Exit: 加载失败时退出
    """
    try:
        return PDFAITool(doc_path)
    except PDFParseError as e:
        print(f"[错误] {e}", file=sys.stderr)
        raise typer.Exit(code=1)
    except FileNotFoundError:
        print(f"[错误] 文件不存在: {doc_path}", file=sys.stderr)
        raise typer.Exit(code=1)
    except Exception as e:
        print(f"[错误] 加载文档失败: {e}", file=sys.stderr)
        raise typer.Exit(code=1)


@app.command()
def outline(
    doc_path: str = typer.Argument(..., help="文档路径（.pdf 或 .json）"),
    id: Optional[str] = typer.Option(None, "--id", "-i", help="起始节点 ID"),
    depth: int = typer.Option(2, "--depth", "-d", help="最大深度限制"),
) -> None:
    """获取文档大纲"""
    tool = _create_tool(doc_path)
    
    node_id = _parse_node_id(id) if id else None
    result = tool.get_outline(node_id, depth)
    
    if result.startswith("[错误]"):
        print(result, file=sys.stderr)
        raise typer.Exit(code=1)
    
    print(result)


@app.command()
def inspect(
    doc_path: str = typer.Argument(..., help="文档路径（.pdf 或 .json）"),
    id: str = typer.Argument(..., help="节点 ID"),
    sibling_count: int = typer.Option(5, "--siblings", "-s", help="显示的前后兄弟节点数量"),
) -> None:
    """透视节点上下文"""
    tool = _create_tool(doc_path)
    
    node_id = _parse_node_id(id)
    result = tool.inspect_node(node_id, sibling_count)
    
    if result.startswith("[错误]"):
        print(result, file=sys.stderr)
        raise typer.Exit(code=1)
    
    print(result)


@app.command()
def search(
    doc_path: str = typer.Argument(..., help="文档路径（.pdf 或 .json）"),
    query: str = typer.Argument(..., help="搜索查询字符串"),
    mode: str = typer.Option("regex", "--mode", "-m", help="搜索模式：regex 或 fuzzy"),
) -> None:
    """搜索文档内容"""
    tool = _create_tool(doc_path)
    
    result = tool.search_nodes(query, mode)
    
    if result.startswith("[错误]"):
        print(result, file=sys.stderr)
        raise typer.Exit(code=1)
    
    print(result)


@app.command()
def read(
    doc_path: str = typer.Argument(..., help="文档路径（.pdf 或 .json）"),
    page: str = typer.Argument(..., help="页码或页码范围，如 12 或 12-15"),
    no_structure: bool = typer.Option(False, "--no-structure", "-n", help="不包含页面结构头部"),
) -> None:
    """读取指定页面内容"""
    tool = _create_tool(doc_path)
    
    include_structure = not no_structure
    result = tool.read_page(page, include_structure=include_structure)
    
    if result.startswith("[错误]"):
        print(result, file=sys.stderr)
        raise typer.Exit(code=1)
    
    print(result)


@app.command()
def content(
    doc_path: str = typer.Argument(..., help="文档路径（.pdf 或 .json）"),
    id: str = typer.Argument(..., help="节点 ID"),
) -> None:
    """获取节点完整内容"""
    tool = _create_tool(doc_path)
    
    node_id = _parse_node_id(id)
    result = tool.get_content(node_id)
    
    if result.startswith("[错误]"):
        print(result, file=sys.stderr)
        raise typer.Exit(code=1)
    
    print(result)


@app.command()
def skill(
    output: Optional[str] = typer.Option(None, "--output", "-o", help="输出目录路径，不指定则输出到 stdout"),
) -> None:
    """生成 Claude Code SKILL.md 文件"""
    skill_content = generate_skill()

    if output:
        from pathlib import Path

        skill_dir = Path(output)
        skill_dir.mkdir(parents=True, exist_ok=True)
        skill_path = skill_dir / "SKILL.md"
        skill_path.write_text(skill_content, encoding="utf-8")
        print(f"Skill 已写入: {skill_path}", file=sys.stderr)
    else:
        print(skill_content)


@app.command()
def mcp(
    transport: str = typer.Option("stdio", "--transport", "-t", help="传输协议：stdio, sse, streamable-http"),
) -> None:
    """启动 MCP Server"""
    from .mcp import run_server
    run_server(transport=transport)  # type: ignore


if __name__ == "__main__":
    app()
